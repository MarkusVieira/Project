/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.projeto.dao;

import br.com.projeto.conexao.Conexao;
import br.com.projeto.modelo.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author FERNANDO
 */
public class ProdutoDao {
     public void adicionar(Produto produto){
        Connection con  = Conexao.getConnection();
        PreparedStatement pstm = null;
        
        try {
            String sql = "insert into produtos (nome,quantidade,preco_venda,preco_compra,fornecedor)values(?,?,?,?,?)";
            pstm = con.prepareStatement(sql);
            
            
            
            pstm.setString(1, produto.getProduto());
            pstm.setInt(2, produto.getQuantidade());
            pstm.setFloat(3, produto.getPrecov());
            pstm.setFloat(4, produto.getPrecoc());  
            pstm.setString(5, produto.getFornecedor());
            
            pstm.execute();
            JOptionPane.showMessageDialog(null,"Adicionado com sucesso.","Sucesso",JOptionPane.INFORMATION_MESSAGE);
            
        } 
        
        catch (SQLException ErroSql) 
        {
            JOptionPane.showMessageDialog(null,"Erro ao adicionar:"+ErroSql,"Erro",JOptionPane.ERROR_MESSAGE);
        }
        finally{
            Conexao.closeConnection(con);
        }
    }
    public void alterar(Produto produto){
    Connection con = Conexao.getConnection();
    PreparedStatement pstm = null;
        try {
           pstm = con.prepareStatement("update produtos set " +
                                       "nome=?, quantidade=?,preco_venda=?,preco_compra=?,fornecedor=?" 
                                      +"where id_produto = ?");
           
           pstm.setString(1, produto.getProduto());
           pstm.setInt(2, produto.getQuantidade());
           pstm.setFloat(3, produto.getPrecov());
           pstm.setFloat(4, produto.getPrecoc());
           pstm.setString(5, produto.getFornecedor());        
           pstm.setInt(6, produto.getId_produto());
           System.out.println("-----" + pstm);
           pstm.executeUpdate();
           JOptionPane.showMessageDialog(null,"Alterado com sucesso.","Sucesso",JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (Exception ErroSql)
        {
            JOptionPane.showMessageDialog(null,"Erro ao Alterar:"+ErroSql,"Erro",JOptionPane.ERROR_MESSAGE);
        }
        finally{
            Conexao.closeConnection(con);
        }
    
    }
    public void excluir(Produto produto){
    Connection con = Conexao.getConnection();
    PreparedStatement pstm=null;
    
        try {
            
           pstm = con.prepareStatement("delete from produtos where id_produto=?");
           
           pstm.setInt(1, produto.getId_produto());
           
           pstm.executeUpdate();
           JOptionPane.showMessageDialog(null,"Excluido com sucesso.","Sucesso",JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (SQLException ErroSql)
        {
             JOptionPane.showMessageDialog(null,"Erro ao Excluir:"+ErroSql,"Erro",JOptionPane.ERROR_MESSAGE);
        }
        finally{
        Conexao.closeConnection(con,pstm);
        }
    
    
    }
    public List<Produto>listar(){
        
        List<Produto>produtos = new ArrayList<>();
        
        Connection con = Conexao.getConnection();
        PreparedStatement pstm = null;
        ResultSet rs = null;
        
        try {
            
            pstm = con.prepareStatement("select*from produtos;");
            rs = pstm.executeQuery();
            
            while(rs.next()){
            
                Produto produto = new Produto();
                produto.setId_produto(rs.getInt("id_produto"));
                produto.setProduto(rs.getString("nome"));
                produto.setQuantidade(rs.getInt("quantidade"));
                produto.setPrecov(rs.getFloat("preco_venda"));
                produto.setPrecoc(rs.getFloat("preco_compra"));
                produto.setFornecedor(rs.getString("fornecedor"));
                
                produtos.add(produto);                          
            }
        } 
        
        catch (SQLException ErroSql)
        {
          JOptionPane.showMessageDialog(null,"Erro ao listar dados:"+ErroSql,"Erro",JOptionPane.ERROR_MESSAGE);
        }
        finally{
        Conexao.closeConnection(con,pstm,rs);
        }
        
        
        return produtos;
    }
}