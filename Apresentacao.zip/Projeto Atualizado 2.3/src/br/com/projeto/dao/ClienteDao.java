/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.projeto.dao;

import br.com.projeto.conexao.Conexao;
import br.com.projeto.modelo.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author FERNANDO
 */
public class ClienteDao {   
    public void adicionar(Cliente cliente){
        Connection con  = Conexao.getConnection();
        PreparedStatement pstm = null;
        
        try {
            String sql = "insert into clientes (bairro,cep,cidade,cpf,endereco,estado,nome,telefone)values(?,?,?,?,?,?,?,?)";
            pstm = con.prepareStatement(sql);
            
            pstm.setString(1, cliente.getBairro());
            pstm.setString(2, cliente.getCep());
            pstm.setString(3, cliente.getCidade());
            pstm.setString(4, cliente.getCpf());
            pstm.setString(5, cliente.getEndereco());      
            pstm.setString(6, cliente.getEstado());  
            pstm.setString(7, cliente.getNome());  
            pstm.setString(8, cliente.getTelefone());   
            pstm.execute();
            JOptionPane.showMessageDialog(null,"Adicionado com sucesso.","Sucesso",JOptionPane.INFORMATION_MESSAGE);
            
        } 
        
        catch (SQLException ErroSql) 
        {
            JOptionPane.showMessageDialog(null,"Erro ao adicionar:"+ErroSql,"Erro",JOptionPane.ERROR_MESSAGE);
        }
        finally{
            Conexao.closeConnection(con);
        }
     
          }
    public void alterar(Cliente cliente){
    Connection con = Conexao.getConnection();
    PreparedStatement pstm = null;
        try {
           pstm = con.prepareStatement("update clientes set " +
                                       "bairro=?, cep=?,cidade=?,cpf=?,endereco=?,estado=?,nome=?,telefone=? " 
                                      +"where id_cliente = ?");
           pstm.setString(1, cliente.getBairro());
           pstm.setString(2, cliente.getCep());
           pstm.setString(3, cliente.getCidade());
           pstm.setString(4, cliente.getCpf());
           pstm.setString(5, cliente.getEndereco());      
           pstm.setString(6, cliente.getEstado());  
           pstm.setString(7, cliente.getNome());  
           pstm.setString(8, cliente.getTelefone());  
           pstm.setInt(9, cliente.getId_cliente());
           System.out.println("-----" + pstm);
           pstm.executeUpdate();
           JOptionPane.showMessageDialog(null,"Alterado com sucesso.","Sucesso",JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (Exception ErroSql)
        {
            JOptionPane.showMessageDialog(null,"Erro ao Alterar:"+ErroSql,"Erro",JOptionPane.ERROR_MESSAGE);
        }
        finally{
            Conexao.closeConnection(con);
        }
    
    }
    public void excluir(Cliente cliente){
    Connection con = Conexao.getConnection();
    PreparedStatement pstm=null;
    
        try {
            
           pstm = con.prepareStatement("delete from clientes where id_cliente=?");
           
           pstm.setInt(1, cliente.getId_cliente());
           
           pstm.executeUpdate();
           JOptionPane.showMessageDialog(null,"Excluido com sucesso.","Sucesso",JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (SQLException ErroSql)
        {
             JOptionPane.showMessageDialog(null,"Erro ao Excluir:"+ErroSql,"Erro",JOptionPane.ERROR_MESSAGE);
        }
        finally{
        Conexao.closeConnection(con,pstm);
        }
    
    
    }
    public List<Cliente>listar(){
        
        List<Cliente>clientes = new ArrayList<>();
        
        Connection con = Conexao.getConnection();
        PreparedStatement pstm = null;
        ResultSet rs = null;
        
        try {
            
            pstm = con.prepareStatement("select*from clientes;");
            rs = pstm.executeQuery();
            
            while(rs.next()){
            
                Cliente cliente = new Cliente();
                cliente.setId_cliente(rs.getInt("id_cliente"));
                cliente.setBairro(rs.getString("bairro"));
                cliente.setCep(rs.getString("cep"));
                cliente.setCidade(rs.getString("cidade"));
                cliente.setCpf(rs.getString("cpf"));
                cliente.setEndereco(rs.getString("endereco"));
                cliente.setEstado(rs.getString("estado"));
                cliente.setNome(rs.getString("nome"));
                cliente.setTelefone(rs.getString("telefone"));
                
                clientes.add(cliente);                          
            }
        } 
        
        catch (SQLException ErroSql)
        {
          JOptionPane.showMessageDialog(null,"Erro ao listar dados:"+ErroSql,"Erro",JOptionPane.ERROR_MESSAGE);
        }
        finally{
        Conexao.closeConnection(con,pstm,rs);
        }
        
        
        return clientes;
    }
}
