/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.projeto.dao;

import br.com.projeto.conexao.Conexao;
import br.com.projeto.modelo.Fornecedor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author Marchetti
 */
public class FornecedorDao {
    public void adicionar(Fornecedor fornecedor){
        Connection con  = Conexao.getConnection();
        PreparedStatement pstm = null;
        
        try {
            String sql = "insert into fornecedores (nome,endereco,telefone,bairro,cidade,estado,cnpj)values(?,?,?,?,?,?,?)";
            pstm = con.prepareStatement(sql);
            
            
            
            pstm.setString(1, fornecedor.getNome());
            pstm.setString(2, fornecedor.getEndereco());
            pstm.setString(3, fornecedor.getTelefone());
            pstm.setString(4, fornecedor.getBairro());
            pstm.setString(5, fornecedor.getCidade());  
            pstm.setString(6, fornecedor.getEstado());
            pstm.setInt(7, fornecedor.getCnpj());
            
            pstm.execute();
            JOptionPane.showMessageDialog(null,"Adicionado com sucesso.","Sucesso",JOptionPane.INFORMATION_MESSAGE);
            
        } 
        
        catch (SQLException ErroSql) 
        {
            JOptionPane.showMessageDialog(null,"Erro ao adicionar:"+ErroSql,"Erro",JOptionPane.ERROR_MESSAGE);
        }
        finally{
            Conexao.closeConnection(con);
        }
    }
    public void alterar(Fornecedor fornecedor){
    Connection con = Conexao.getConnection();
    PreparedStatement pstm = null;
        try {
           pstm = con.prepareStatement("update fornecedores set " +
                                       "nome=?, endereco=?,telefone=?,bairro=?,cidade=?,estado=?,cnpj=?" 
                                      +" where id_fornecedor = ?");
           
           pstm.setString(1, fornecedor.getNome());
           pstm.setString(2, fornecedor.getEndereco());
           pstm.setString(3, fornecedor.getTelefone());
           pstm.setString(4, fornecedor.getBairro());
           pstm.setString(5, fornecedor.getCidade());        
           pstm.setString(6, fornecedor.getEstado());
           pstm.setInt(7, fornecedor.getCnpj());
           pstm.setInt(8, fornecedor.getId_fornecedor());
           System.out.println("-----" + pstm);
           pstm.executeUpdate();
           JOptionPane.showMessageDialog(null,"Alterado com sucesso.","Sucesso",JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (Exception ErroSql)
        {
            JOptionPane.showMessageDialog(null,"Erro ao Alterar:"+ErroSql,"Erro",JOptionPane.ERROR_MESSAGE);
        }
        finally{
            Conexao.closeConnection(con);
        }
    
    }
    public void excluir(Fornecedor fornecedor){
    Connection con = Conexao.getConnection();
    PreparedStatement pstm=null;
    
        try {
            
           pstm = con.prepareStatement("delete from fornecedores where id_fornecedor=?");
           
           pstm.setInt(1, fornecedor.getId_fornecedor());
           
           pstm.executeUpdate();
           JOptionPane.showMessageDialog(null,"Excluido com sucesso.","Sucesso",JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (SQLException ErroSql)
        {
             JOptionPane.showMessageDialog(null,"Erro ao Excluir:"+ErroSql,"Erro",JOptionPane.ERROR_MESSAGE);
        }
        finally{
        Conexao.closeConnection(con,pstm);
        }
    
    
    }
    public List<Fornecedor>listar(){
        
        List<Fornecedor>fornecedores = new ArrayList<>();
        
        Connection con = Conexao.getConnection();
        PreparedStatement pstm = null;
        ResultSet rs = null;
        
        try {
            
            pstm = con.prepareStatement("select*from fornecedores;");
            rs = pstm.executeQuery();
            
            while(rs.next()){
            
                Fornecedor fornecedor = new Fornecedor();
                fornecedor.setId_fornecedor(rs.getInt("id_fornecedor"));
                fornecedor.setNome(rs.getString("nome"));
                fornecedor.setEndereco(rs.getString("endereco"));
                fornecedor.setTelefone(rs.getString("telefone"));
                fornecedor.setBairro(rs.getString("bairro"));
                fornecedor.setCidade(rs.getString("cidade"));
                fornecedor.setEstado(rs.getString("estado"));
                fornecedor.setCnpj(rs.getInt("cnpj"));
                
                fornecedores.add(fornecedor);                          
            }
        } 
        
        catch (SQLException ErroSql)
        {
          JOptionPane.showMessageDialog(null,"Erro ao listar dados:"+ErroSql,"Erro",JOptionPane.ERROR_MESSAGE);
        }
        finally{
        Conexao.closeConnection(con,pstm,rs);
        }
        
        
        return fornecedores;
    }
}