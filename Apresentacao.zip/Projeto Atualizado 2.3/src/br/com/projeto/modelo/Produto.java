/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.projeto.modelo;

/**
 *
 * @author FERNANDO
 */
public class Produto {

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public float getPrecoc() {
        return precoc;
    }

    public void setPrecoc(float precoc) {
        this.precoc = precoc;
    }

    public float getPrecov() {
        return precov;
    }

    public void setPrecov(float precov) {
        this.precov = precov;
    }

    public int getId_produto() {
        return id_produto;
    }

    public void setId_produto(int id_produto) {
        this.id_produto = id_produto;
    }

    private String fornecedor;
    private String produto;
    private int quantidade;
    private float precoc;
    private float precov;
    private int id_produto;

}
