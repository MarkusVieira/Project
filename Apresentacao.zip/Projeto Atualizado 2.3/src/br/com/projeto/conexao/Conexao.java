/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.projeto.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author FERNANDO
 */
public class Conexao {
    public Statement stm; // responsavel por preparar e realizar pesquisas no banco de dados
    public ResultSet rs;
    public Connection conn; 
    
    
      private static final String DRIVE = "com.mysql.jdbc.Driver";
      private static final String URL = "jdbc:mysql://localhost/projeto";
      private static final String USUARIO = "root";
      private static final String SENHA= "";
      
       public void  conexao () { // Metodo responsavel por realizar a conexão com o mySQL
            try { // Bloco lógico Boleano
                System.setProperty ("jdbc.Drivers", DRIVE); // seta a propriedade do Driver de conexão
                conn = DriverManager.getConnection (URL, USUARIO, SENHA); // realiza a conexão com o mySQL
                //JOptionPane.showMessageDialog (null, "MySQL conectado com sucesso!"); // Valida a conexão (True)
            } catch (SQLException ex) {
                Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Erro de conexão!"); // False
            }
        }
        
        public void desconecta(){ // Fechar a conexão mySQL
            try {
                conn.close();
                JOptionPane.showMessageDialog (null, "Desconectado com sucesso");
            } catch (SQLException ex) {
                Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog (null, "Erro ao fechar a conexão");
            }
        }

        public void executaSQL(String sql) throws SQLException{
        stm = (Statement) conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
        rs = stm.executeQuery(sql);
        }
      
      public static Connection getConnection(){
          try {
              Class.forName(DRIVE);
              return DriverManager.getConnection(URL,USUARIO,SENHA);
          } catch (ClassNotFoundException | SQLException ErroSql) {
              throw new RuntimeException("ERRO! Não foi possível conectar. "+ErroSql);
          }
      }
      public static void  closeConnection(Connection con    ){
          try {
              if(con!=null)
                  con.close();
          } catch (SQLException ErroSql) {
              throw new RuntimeException("Erro! Não foi possível fechar a conexão. "+ErroSql);
          }
      
      }
        public static void  closeConnection(Connection con,PreparedStatement pstm    ){
            closeConnection(con);
          try {
              if(pstm!=null)
                  pstm.close();
          } catch (SQLException ErroSql) {
              throw new RuntimeException("Erro! Não foi possível fechar o PreparedStatement. "+ErroSql);
          }
        }
        
            public static void  closeConnection(Connection con,PreparedStatement pstm,ResultSet rs    ){
            closeConnection(con,pstm);
          try {
              if(rs!=null)
                  rs.close();
          } catch (SQLException ErroSql) {
              throw new RuntimeException("Erro! Não foi possível fechar o ResultSet. "+ErroSql);
          }
        }
       
}
